package com.bonniewhy.thechorewheel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheChoreWheelApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheChoreWheelApplication.class, args);
	}

}
